import create from 'zustand';

interface UserState {
    user: UserAuth
    setUser: (user: UserAuth) => void
    removeUser: () => void
}

const getLocalStorage = (key: string): UserAuth => JSON.parse(window.localStorage.getItem(key) as string);
const setLocalStorage = (key: string, value: UserAuth) => window.localStorage.setItem(key, JSON.stringify(value));

const useStore = create<UserState>((set) => ({
    user: getLocalStorage("user") || {userId: -1, token: ""},
    setUser: (user: UserAuth) => set(() => {
        setLocalStorage("user", user)
        return {user: user}
    }),
    removeUser: () => set(() => {
        localStorage.clear()
        return {}
    })
}))

export const useUserStore = useStore;