import {
    Alert,
    AlertTitle,
    Button,
    Container,
    Grid,
    Paper,
    Snackbar,
    TextField,
    Toolbar,
    Tooltip,
    Typography
} from "@mui/material";
import CSS from "csstype";
import React from "react";
import axios from "axios";
import {useUserStore} from "../store/index.ts"
import {useNavigate} from "react-router";
import AppBarObject from "../components/AppBarObject.tsx";

const RegisterLogin = () => {
    const user = useUserStore(state => state.user)
    const setUser = useUserStore(state => state.setUser)
    //register and login vars
    const [firstName, setFirstName] = React.useState("")
    const [lastName, setLastName] = React.useState("")
    const [email, setEmail] = React.useState("")
    const [password, setPassword] = React.useState("")
    //img vars
    const [photo, setPhoto] = React.useState<File | null>(null)
    const fileInputRef = React.useRef<HTMLInputElement>(null)
    //error files
    const [errorFlag, setErrorFlag] = React.useState(false)
    const [errorMessage, setErrorMessage] = React.useState("")
    //sjx vars
    const [isRegister, setIsRegister] = React.useState(false)
    const [isHidden, setIsHidden] = React.useState(true)
    const navigate = useNavigate()



    //axios methods
    const registerUser = () => {
        //check if logged in
        if (user.token != "") {
            setSnackMessage("Already logged in.")
            setSnackOpen(true)
            return
        }
        //create new user (axios.post)
        axios.post('http://localhost:4941/api/v1/users/register', { email, firstName, lastName, password })
            .then(() => {
                loginUser()
            }, (error)  => {
                setErrorFlag(true)
                setErrorMessage(error.toString())
                console.log(error)
                if (error.response.status == 400) {
                    setSnackMessage("Bad Request. Please make sure all fields are correct.") //invalid info
                    setSnackOpen(true)
                }
                if (error.response.status == 403) {
                    setSnackMessage("Email already in use. Please use a different email.")  //email in use
                    setSnackOpen(true)
                }
            })
    }

    const loginUser = () => {
        if (user.token != "") {
            setSnackMessage("Already logged in.")
            setSnackOpen(true)
            return
        }
        axios.post('http://localhost:4941/api/v1/users/login', { email, password })
            .then((response) => {
               setUser(response.data)
                updateProfileImg(response.data)
            }, (error) => {
            setErrorFlag(true)
            setErrorMessage(error.toString())
            console.log(error)
            if (error.response.status == 400) {
                setSnackMessage("Bad Request. Please make sure all fields are correct.") //invalid info
                setSnackOpen(true)
            }
            if (error.response.status == 401) {
                setSnackMessage("UnAuthorized. Incorrect email or password.") //invalid info
                setSnackOpen(true)
            }
        })
    }

    const updateProfileImg = (userAuth: UserAuth) => {
        if (userAuth.token == "") {
            return
        }
        if (photo == null) {
            navigate('/petitions')
            return
        }
        axios.put('http://localhost:4941/api/v1/users/' + userAuth.userId + "/image", photo, {headers:{"X-Authorization": userAuth.token, "Content-type": photo.type}})
            .then(() => {
                navigate('/petitions')
            }, (error)  => {
                setErrorFlag(true)
                setErrorMessage(error.toString())
                console.log(error)
            })
    }



    //login handler
    const handleLoginClick = () => {
        loginUser()
    }



    //state update methods
    const updateFirstName = (event: { target: { value: React.SetStateAction<string>; }; }) => {
        setFirstName(event.target.value)
    }

    const updateLastName = (event: { target: { value: React.SetStateAction<string>; }; }) => {
        setLastName(event.target.value)
    }

    const updateEmail = (event: { target: { value: React.SetStateAction<string>; }; }) => {
        setEmail(event.target.value)
    }

    const updatePassword = (event: { target: { value: React.SetStateAction<string>; }; }) => {
        setPassword(event.target.value)
    }

    const updateIsRegister = () => {
        setIsRegister(!isRegister)
    }



    //img handlers
    const handlePhotoChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        setPhoto(event.target.files[0])
    }

    const handlePhotoClick = () => {
        if (fileInputRef.current) {
            fileInputRef.current.click();
        }
    };



    //snacks
    const [snackOpen, setSnackOpen] = React.useState(false)
    const [snackMessage, setSnackMessage] = React.useState("")
    const handleSnackClose = (event?: React.SyntheticEvent | Event, reason?: string) => {
        if (reason === 'clickaway') {
            return;
        }
        setSnackOpen(false);
    };

    const card: CSS.Properties = {
        padding: "10px",
        margin: "20px",
        display: "block",
        width: "1400px",
    }

    return (
        <div>
            <AppBarObject/>
            <Paper style={card}>
                <h1>Petitions For Days</h1>
                { isRegister == true &&
                    <div>
                        <Container>
                            <TextField id="outlined-basic" label="First" value={firstName} onChange={updateFirstName}/>
                        </Container>
                        <Container>
                            <TextField id="outlined-basic" label="Last" value={lastName} onChange={updateLastName}/>
                        </Container>
                        <Container>
                            <TextField id="outlined-basic" label="Email" value={email} onChange={updateEmail}/>
                        </Container>
                        <Container>
                            <TextField id="outlined-basic" label="Password" type={isHidden ? "password" : "text"} value={password} onChange={updatePassword}/>
                        </Container>
                        <Button onClick={handlePhotoClick}>
                            Add Profile Photo
                        </Button>
                        <Typography>
                            {photo?.name}
                        </Typography>
                        <input
                            type="file"
                            accept=".png, .jpg, .jpeg, .gif"
                            ref={fileInputRef}
                            style={{display: 'none'}}
                            onChange={handlePhotoChange}
                        />
                        <button onClick={registerUser}>Register</button>
                        <button onClick={updateIsRegister}>Existing user login</button>
                    </div>
                }
                { isRegister == false &&
                    <div>
                        <Container>
                            <TextField id="outlined-basic" label="Email" value={email} onChange={updateEmail}/>
                        </Container>
                        <Container>
                            <TextField id="outlined-basic" label="Password" type={isHidden ? "password" : "text"} value={password} onChange={updatePassword}/>
                        </Container>
                        <button onClick={handleLoginClick}>Login</button>
                        <button onClick={updateIsRegister}>Register as a new user</button>
                    </div>
                }
                <button onClick={() => setIsHidden(!isHidden)}>Show Password</button>
            </Paper>
            { errorFlag &&
                <Alert severity="error">
                    <AlertTitle>Error</AlertTitle>
                    {errorMessage}
                </Alert>
            }
            <Snackbar
                autoHideDuration={6000}
                open={snackOpen}
                onClose={handleSnackClose}
                key={snackMessage}
            >
                <Alert onClose={handleSnackClose} severity="error" sx={{width: '100%'}}>
                    {snackMessage}
                </Alert>
            </Snackbar>
        </div>
    )
}

export default RegisterLogin