import AppBarObject from "../components/AppBarObject.tsx";
import UserProfileObject from "../components/UserProfileObject.tsx";

const UserProfile = () => {

    return (
        <div>
            <AppBarObject/>
            <UserProfileObject/>
        </div>
    )
}

export default UserProfile