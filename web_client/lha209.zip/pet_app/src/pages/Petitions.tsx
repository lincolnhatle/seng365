//ATTEMPTING TO MAKE LAB 4 WAY
import axios from "axios";
import React from "react";

const Petitions = () => {
    const [petitions, setPetitions] = React.useState<Array<Petition>>([])
    const [errorFlag, setErrorFlag] = React.useState(false)
    const [errorMessage, setErrorMessage] = React.useState("")

    React.useEffect(() => {
        getPetitions()
    }, [])

    const getPetitions = () => {
        axios.get('http://localhost:4941/api/v1/petitions')
            .then((response) => {
                setErrorFlag(false)
                setErrorMessage("")
                setPetitions(response.data.petitions)
            }, (error) => {
                setErrorFlag(true)
                setErrorMessage(error.toString())
            })
    }

    const [searchWord, setSearchWord] = React.useState("")
    const searchPetitions = () => {

    }

    const updateSearchWordState = (event: { target: { value: React.SetStateAction<string>; }; }) => {
        setSearchWord(event.target.value)
    }

    const list_of_petitions = () => {
        return petitions.map((item: Petition) =>
            <tr key={item.petitionId}>
                <th scope="row">{item.petitionId}</th>
                <td>{item.title}</td>
            </tr>
        )
    }

    if (errorFlag) {
        return (
            <div>
                <h1>Petitions</h1>
                <div style={{ color: "red" }}>
                    {errorMessage}
                </div>
            </div>
        )
    } else {
        return (
            <div>
                <h1>Petitions</h1>
                <h2>Search Petitions</h2>
                <form onSubmit={searchPetitions}>
                    <input type="text" value={searchWord} onChange={updateSearchWordState}/>
                    <input type={"submit"} value={"Submit"}/>
                </form>
                <table className="table">
                    <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">username</th>
                        <th scope="col">link</th>
                    </tr>
                    </thead>
                    <tbody>
                    {list_of_petitions()}
                    </tbody>
                </table>
            </div>
        )
    }
}
export default Petitions