import axios from 'axios';
import React from "react";
import CSS from 'csstype';
import {
    Paper,
    AlertTitle,
    Alert,
    TextField,
    Menu,
    MenuItem,
    ListItemIcon,
    Icon,
    ListItem,
    DialogTitle,
    DialogContent,
    DialogContentText,
    DialogActions,
    Button,
    Dialog,
    Typography,
    Container,
    Toolbar,
    Box,
    Snackbar, Grid, FormControlLabel, Checkbox, FormGroup, Select, responsiveFontSizes
} from "@mui/material";
import PetitionListObject from '../components/PetitionListObject.tsx';
import AppBarObject from "../components/AppBarObject.tsx";
import {ArrowDropDown, Category, CategoryOutlined, Check, Description} from "@mui/icons-material";
import {useUserStore} from "../store";
import SupportTierListObject from "../components/SupportTierListObject.tsx";

const PetitionList = () => {
    const user = useUserStore(state => state.user)
    //petition list vars
    const [petitions, setPetitions] = React.useState<Array<Petition>>([])
    const [searchWord, setSearchWord] = React.useState("")
    const [sortBy, setSortBy] = React.useState("CREATED_ASC")
    const [filterCategories, setFilterCategories] = React.useState<Array<number>>([])
    const [filterCost, setFilterCost] = React.useState(99999999)
    const [startIndex, setStartIndex] = React.useState(0)
    const [categories, setCategories] = React.useState([])
    //error vars
    const [errorFlag, setErrorFlag] = React.useState(false)
    const [errorMessage, setErrorMessage] = React.useState("")
    //petition vars
    const [title, setTitle] = React.useState("")
    const [description, setDescription] = React.useState("")
    const [categoryId, setCategoryId] = React.useState(0)
    const [supportTiers, setSupportTiers] = React.useState<Array<SupportTier>>([])
    const [heroImg, setHeroImg] = React.useState<File | null>(null)
    //image select vars
    const fileInputRef = React.useRef<HTMLInputElement>(null)
    //support tier vars
    const [supportTierTitle, setSupportTierTitle] = React.useState("")
    const [supportTierDescription, setSupportTierDescription] = React.useState("")
    const [supportTierCost, setSupportTierCost] = React.useState(0)
    //page vars
    const [pageNumber, setPageNumber] = React.useState(1)
    const count = 6
    const [numPetitions, setNumPetitions] = React.useState(1000)


    React.useEffect(() => {
        getPetitions(startIndex)
        getNumPetitions()
        getCategories()
    }, [setPetitions])



    //axios methods
    const getCategories = () => {
        axios.get('http://localhost:4941/api/v1/petitions/categories')
            .then((response) => {
                setCategories(response.data)
            }, (error)  => {
                setErrorFlag(true)
                setErrorMessage(error.toString())
            })
    }

    // const getPetitions = (sort: string) => {
    //     axios.get('http://localhost:4941/api/v1/petitions?sortBy=' + sort)
    //         .then((response) => {
    //             setPetitions(response.data.petitions)
    //         }, (error)  => {
    //             setErrorFlag(true)
    //             setErrorMessage(error.toString())
    //         })
    // }

    // const searchPetitions = (sort: string) => {
    //     if (searchWord == "") {
    //         return
    //     }
    //     event?.preventDefault()
    //     axios.get('http://localhost:4941/api/v1/petitions' + '?q=' + searchWord + '&sortBy=' + sort)
    //         .then((response) => {
    //             setPetitions(response.data.petitions)
    //         }, (error)  => {
    //             setErrorFlag(true)
    //             setErrorMessage(error.toString())
    //         })
    // }

    const getPetitions = (start: number) => {
        const params: {
            startIndex?: number,
            count: number,
            q?: string,
            categoryIds?: number[],
            supportingCost?: number,
            sortBy?: string
        } = {
            count: count
        }
        if (filterCost || filterCost == 0) {
            params.supportingCost = filterCost
        }
        if (filterCategories) {
            params.categoryIds = filterCategories
        }
        if (sortBy) {
            params.sortBy = sortBy
        }
        if (searchWord) {
            params.q = searchWord
        }
        params.startIndex = start

        // axios.get('http://localhost:4941/api/v1/petitions' + '?supportingCost=' + filterCost + '&categoryIds=' + filterCategories + '&sortBy=' + sort)
        axios.get('http://localhost:4941/api/v1/petitions', {params})
            .then((response) => {
                setPetitions(response.data.petitions)
            }, (error)  => {
                setErrorFlag(true)
                setErrorMessage(error.toString())
            })
    }

    const postPetition = () => {
        if (heroImg == null) {
            setSnackMessage("Please add a hero image for your petition") //invalid info
            setSnackOpen(true)
            return
        }
        axios.post('http://localhost:4941/api/v1/petitions', { title, description, categoryId, supportTiers }, {headers: {"X-Authorization": user.token}})
            .then((response) => {
                console.log(response)
                putPetitionImage(response.data.petitionId)
            }, (error) => {
                console.log(error)
                if (error.response.status == 403) {
                    setSnackMessage("A petition already exists with that title.") //invalid info
                    setSnackOpen(true)
                }
                if (error.response.status == 400) {
                    console.log("reached")
                    setSnackMessage("Bad request. Please make sure all required fields are filled.") //invalid info
                    setSnackOpen(true)
                }
            })
    }

    const putPetitionImage = (petitionId: number) => {
        axios.put('http://localhost:4941/api/v1/petitions/' + petitionId + '/image', heroImg, {headers: {"X-Authorization": user.token, "Content-type": heroImg?.type}})
            .then((response) => {
                console.log(response)
                handleCreateDialogClose()
            }, (error) => {
                setSnackMessage(error.toString()) //invalid info
                setSnackOpen(true)
            })
    }



    //create dialog
    const [openCreateDialog, setOpenCreateDialog] = React.useState(false)
    const handleCreateDialogOpen = () => {
        if (user.token == "") {
            setSnackMessage("Please log in to create a petition.")
            setSnackOpen(true)
            return
        }
        //reset all the variables
        setTitle("")
        setDescription("")
        setCategoryId(0)
        setSupportTiers([])
        setHeroImg(null)
        setOpenCreateDialog(true)
    }
    const handleCreateDialogClose = () => {
        getPetitions(startIndex)
        setOpenCreateDialog(false)
    }



    //filter dialog
    const [openFilterDialog, setOpenFilterDialog] = React.useState(false)
    const handleFilterDialogOpen = () => {
        setOpenFilterDialog(true)
    }
    const handleFilterDialogClose = () => {
        getPetitions(startIndex)
        setOpenFilterDialog(false)
    }



    //photo handling
    const handlePhotoChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        setHeroImg(event.target.files[0])
    }
    const handlePhotoClick = () => {
        if (fileInputRef.current) {
            fileInputRef.current.click();
        }
    };



    //support tier handling
    const handleSupportTierClick = () => {
        if (supportTierDescription == "" || supportTierTitle == "") { //if not all fields are full then send snackbar alert
            setSnackMessage("Please fill out all support tier fields.") //invalid info
            setSnackOpen(true)
            return
        }
        if (supportTiers.length > 2) {
            setSnackMessage("You may have no more than 3 support tiers.") //invalid info
            setSnackOpen(true)
            return
        }
        //add support tier
        supportTiers.push({ "title": supportTierTitle, "description": supportTierDescription, "cost": supportTierCost })
        console.log(supportTiers)
        //reset values
        setSupportTierTitle("")
        setSupportTierDescription("")
        setSupportTierCost(0)
    }



    //pagination handling
    const handleNextPageClick = () => {
        if (startIndex + count <= numPetitions) {
            setStartIndex(startIndex + count)
            setPageNumber(pageNumber + 1)
            getPetitions(startIndex + count)
        } else {
            setSnackMessage("There are no more petitions to view.")
            setSnackOpen(true)
        }        setNumPetitions(numPetitions)

    }
    const handlePrevPageClick = () => {
        if (startIndex >= 6) {
            setStartIndex(startIndex - count)
            setPageNumber(pageNumber - 1)
            getPetitions(startIndex - count)
        } else {
            setSnackMessage("There is no previous page.")
            setSnackOpen(true)
        }
    }
    const handleFirstPageClick = () => {
        setStartIndex(0)
        setPageNumber(1)
        getPetitions(0)
    }
    const handleLastPageClick = () => {
        console.log("numPets",numPetitions)
        console.log("page num", Math.floor((numPetitions / count) + 1) )
        console.log("start index", Math.floor(numPetitions /count) * count)
        setStartIndex(Math.floor(numPetitions /count) * count)
        setPageNumber(Math.floor((numPetitions / count) + 1))
        getPetitions(Math.floor(numPetitions /count) * count)
    }
    const getNumPetitions = () => {
        axios.get('http://localhost:4941/api/v1/petitions')
            .then((response) => {
                setNumPetitions(response.data.petitions.length)
            })
    }


    //state update methods
    const updateSearchWordState = (event: { target: { value: React.SetStateAction<string>; }; }) => {
        setSearchWord(event.target.value)
    }

    const updateSortByState = (event: { target: { value: React.SetStateAction<string>; }; }) => {
        setSortBy(event.target.value)
    }

    const updateTitleState = (event: { target: { value: React.SetStateAction<string>; }; }) => {
        setTitle(event.target.value)
    }

    const updateDescriptionState = (event: { target: { value: React.SetStateAction<string>; }; }) => {
        setDescription(event.target.value)
    }

    const updateCategoryIdState = (event: React.ChangeEvent<{ value: unknown }>) => {
        setCategoryId(event.target.value)
    }

    const updateSupportTierTitleState = (event: { target: { value: React.SetStateAction<string>; }; }) => {
        setSupportTierTitle(event.target.value)
    }

    const updateSupportTierDescriptionState = (event: { target: { value: React.SetStateAction<string>; }; }) => {
        setSupportTierDescription(event.target.value)
    }

    const updateSupportTierCostState = (event) => {
        const newValue = parseInt(event.target.value, 10); // 10 is the radix/base

        // Check if newValue is a valid number
        if (!isNaN(newValue)) {
            setSupportTierCost(newValue);
        } else {
            console.error('Invalid input value. Please enter a valid number.');
        }
    }

    const updateFilterCostState = (event) => {
        const newValue = parseInt(event.target.value, 10); // 10 is the radix/base

        // Check if newValue is a valid number
        if (!isNaN(newValue)) {
            setFilterCost(newValue);
        } else {
            console.error('Invalid input value. Please enter a valid number.');
        }
    }

    const updateFilterCategoriesState = (event: React.ChangeEvent<{ value: number[] }>) => {
        setFilterCategories(event.target.value || [])
    }


    //lists
    const petition_rows = () => petitions.map((petition: Petition) =>
        <PetitionListObject key={ petition.petitionId + petition.title } petition= {petition} categories={categories}/>)



    //snacks
    const [snackOpen, setSnackOpen] = React.useState(false)
    const [snackMessage, setSnackMessage] = React.useState("")
    const handleSnackClose = (event?: React.SyntheticEvent | Event, reason?: string) => {
        if (reason === 'clickaway') {
            return;
        }
        setSnackOpen(false);
    };



    //css styles
    const card: CSS.Properties = {
        padding: "10px",
        margin: "20px",
        width: "1500px"
    }



    return (
        <div>
            <AppBarObject/>
            <h1>
                {"Petitions Page " + pageNumber}
            </h1>
            <h2>Search Petitions</h2>
            <Container>
                <TextField type="text" value={searchWord} onChange={updateSearchWordState}/>
                <button onClick={() => {
                    getPetitions(startIndex)
                }}>
                    Search
                </button>
            </Container>
            <Container>
                <Box sx={{p: 2}}>
                    <TextField
                        required
                        select
                        id={"outlined-select-required"}
                        label={"Sort By"}
                        value={sortBy}
                        onChange={updateSortByState}
                    >
                        <MenuItem value={"ALPHABETICAL_ASC"}>
                            ALPHABETICAL_ASC
                        </MenuItem>
                        <MenuItem value={"ALPHABETICAL_DESC"}>
                            ALPHABETICAL_DESC
                        </MenuItem>
                        <MenuItem value={"COST_ASC"}>
                            COST_ASC
                        </MenuItem>
                        <MenuItem value={"COST_DESC"}>
                            COST_DESC
                        </MenuItem>
                        <MenuItem value={"CREATED_ASC"}>
                            CREATED_ASC
                        </MenuItem>
                        <MenuItem value={"CREATED_DESC"}>
                            CREATED_DESC
                        </MenuItem>
                    </TextField>
                    <button onClick={() => getPetitions(startIndex)}>
                        Sort
                    </button>
                </Box>
                <button onClick={handleFilterDialogOpen}>
                    Filter
                </button>
                <button onClick={handleCreateDialogOpen}>
                    Create
                </button>
            </Container>
            <Paper elevation={3} style={card}>
                <div style={{flexWrap: "wrap", display: "inline-flex"}}>
                    {errorFlag ?
                        <Alert severity="error">
                            <AlertTitle> Error </AlertTitle>
                            {errorMessage}
                        </Alert> : ""}
                    {petition_rows()}
                </div>
            </Paper>
            <Button onClick={handleFirstPageClick}>First Page</Button>
            <Button onClick={handlePrevPageClick}>Prev Page</Button>
            <Button onClick={handleNextPageClick}>
                {"Next Page(" + (startIndex + count) + "-" + (startIndex + (count * 2)) + ")"}
            </Button>
            <Button onClick={handleLastPageClick}>Last Page</Button>
            <Dialog
                open={openCreateDialog}
                onClose={handleCreateDialogClose}
                aria-labelledby="alert-dialog-title"
                aria-describedby="alert-dialog-description">
                <DialogTitle id="alert-dialog-title">
                    Create a Petition
                </DialogTitle>
                <DialogContent style={{minWidth: "1000px"}}>
                    <Container disableGutters>
                        <TextField required id={"outlined-required"} label={"Title"} value={title}
                                   onChange={updateTitleState}/>
                    </Container>
                    <Container disableGutters>
                        <TextField required id={"outlined-required"} label={"Description"} value={description}
                                   onChange={updateDescriptionState}/>
                    </Container>
                    <Container disableGutters>
                        <TextField
                            required
                            select
                            id={"outlined-select-required"}
                            label={"Category"}
                            value={categoryId}
                            onChange={updateCategoryIdState}
                        >
                            {categories.map((category: Category) => (
                                <MenuItem key={category.name} value={category.categoryId}>
                                    {category.name}
                                </MenuItem>
                            ))}
                        </TextField>
                    </Container>
                    <Button onClick={handlePhotoClick}>
                        Add Petition Photo
                    </Button>
                    <Typography>
                        {heroImg?.name}
                    </Typography>
                    <input
                        type="file"
                        accept=".png, .jpg, .jpeg, .gif"
                        ref={fileInputRef}
                        style={{display: 'none'}}
                        onChange={handlePhotoChange}
                    />
                    <h4>Support Tier</h4>
                    <TextField required id={"outlined-required"} label={"Title"} type={"string"}
                               value={supportTierTitle} onChange={updateSupportTierTitleState}></TextField>
                    <TextField required id={"outlined-required"} label={"Description"} type={"string"}
                               value={supportTierDescription} onChange={updateSupportTierDescriptionState}></TextField>
                    <TextField required id={"outlined-required"} label={"Cost"} type={"number"} value={supportTierCost}
                               onChange={updateSupportTierCostState}></TextField>
                    <Button onClick={handleSupportTierClick}>
                        Add Support Tier
                    </Button>
                </DialogContent>
                <DialogActions>
                    <Button onClick={handleCreateDialogClose}>Cancel</Button>
                    <Button variant="outlined" color="success" onClick={() => {
                        postPetition()
                    }} autoFocus>
                        Post
                    </Button>
                </DialogActions>
            </Dialog>
            <Dialog
                open={openFilterDialog}
                onClose={handleFilterDialogClose}
                aria-labelledby="alert-dialog-title"
                aria-describedby="alert-dialog-description">
                <DialogTitle id="alert-dialog-title">
                    Filter Petitions
                </DialogTitle>
                <DialogContent style={card}>
                    <TextField required id={"outlined-required"} label={"Max Supporting Cost"} type={"number"}
                               value={filterCost} onChange={updateFilterCostState}></TextField>
                    <Select
                        multiple
                        label={"Categories"}
                        value={filterCategories}
                        onChange={updateFilterCategoriesState}
                    >
                        {categories.map((category: Category) => (
                            <MenuItem key={category.name} value={category.categoryId}>
                                {category.name}
                            </MenuItem>
                        ))}
                    </Select>
                </DialogContent>
                <DialogActions>
                    <Button onClick={handleFilterDialogClose}>Cancel</Button>
                    <Button variant="outlined" color="info" onClick={() => {
                        getPetitions(startIndex)
                        handleFilterDialogClose()
                    }} autoFocus>
                        Filter
                    </Button>
                </DialogActions>
            </Dialog>
            <Snackbar
                autoHideDuration={6000}
                open={snackOpen}
                onClose={handleSnackClose}
                key={snackMessage}
            >
                <Alert onClose={handleSnackClose} severity="error" sx={{width: '100%'}}>
                    {snackMessage}
                </Alert>
            </Snackbar>
        </div>
    )
}

export default PetitionList