import {
    Alert,
    AlertTitle,
    Button,
    Container,
    Dialog, DialogActions,
    DialogContent,
    DialogTitle, Menu, MenuItem,
    Paper, Select,
    Snackbar,
    TextField, Typography
} from "@mui/material";
import React from "react";
import CSS from "csstype";
import {useParams} from "react-router-dom";
import axios from "axios";
import PetitionDetailsObject from "../components/PetitionDetailsObject.tsx";
import SupportTierListObject from "../components/SupportTierListObject.tsx";
import SupporterObject from "../components/SupporterObject.tsx";
import PetitionListObject from "../components/PetitionListObject.tsx";
import AppBarObject from "../components/AppBarObject.tsx";
import {useUserStore} from "../store";
import {Category} from "@mui/icons-material";

const PetitionDetails = () => {
    //user var
    const user = useUserStore(state => state.user)
    //petition details vars
    const {petitionId} = useParams()
    const [petition, setPetition] = React.useState<PetitionFull>({
        categoryId: 0,
        creationDate: "",
        description: "",
        moneyRaised: 0,
        numberOfSupporters: 0,
        ownerFirstName: "",
        ownerId: 0,
        ownerLastName: "",
        petitionId: 0,
        supportTiers: [],
        title: "",
        supportingCost: 0
    })
    const [petitions, setPetitions] = React.useState<Array<Petition>>([])
    const [categories, setCategories] = React.useState([])
    const [supportTiers, setSupportTiers] = React.useState<Array<SupportTierPost>>([])
    const [supporters, setSupporters] = React.useState<Array<Supporter>>([])
    //edit vars
    const [newTitle, setNewTitle] = React.useState("")
    const [newDescription, setNewDescription] = React.useState("")
    const [newCategory, setNewCategory] = React.useState(0)
    //edit supportTiers vars
    const [supportTierTitle, setSupportTierTitle] = React.useState("")
    const [supportTierDescription, setSupportTierDescription] = React.useState("")
    const [supportTierCost, setSupportTierCost] = React.useState(0)
    //error vars
    const [errorFlag, setErrorFlag] = React.useState(false)
    const [errorMessage, setErrorMessage] = React.useState("")



    React.useEffect(() => {
        getPetition()
        getSupporters()
        getCategories()
    }, [petitionId])



    //axios methods
    const getPetition = () => {
        axios.get('http://localhost:4941/api/v1/petitions/' + petitionId)
            .then((response) => {
                setPetition(response.data)
                setSupportTiers(response.data.supportTiers)
                // console.log("petition",response.data)
                // console.log("tiers", response.data.supportTiers)
                getSimilarPetitions(response.data.categoryId, response.data.ownerId)
            }, (error) => {
                setErrorFlag(true)
                setErrorMessage(error.toString())
            })
    }

    const getSupporters = () => {
        axios.get('http://localhost:4941/api/v1/petitions/' + petitionId + "/supporters")
            .then((response) => {
                setSupporters(response.data)
            }, (error) => {
                setErrorFlag(true)
                setErrorMessage(error.toString())
            })
    }

    const getCategories = () => {
        axios.get('http://localhost:4941/api/v1/petitions/categories')
            .then((response) => {
                setCategories(response.data)
            }, (error)  => {
                setErrorFlag(true)
                setErrorMessage(error.toString())
            })
    }

    //might need two separate methods
    const getSimilarPetitions = (categoryId: number, ownerId: number) => {
        axios.get('http://localhost:4941/api/v1/petitions' + '?ownerId=' + ownerId)
            .then((response) => {
                axios.get('http://localhost:4941/api/v1/petitions' + '?categoryIds=' + [categoryId])
                    .then((response1) => {

                        function contains(petition: Petition, list: Petition[]) {
                            return list.some(item => {
                                return item.petitionId === petition.petitionId
                            })
                        }

                        const combinedList = [...response.data.petitions];

                        for (let petition of response1.data.petitions) {
                            if (!contains(petition, combinedList)) {
                                combinedList.push(petition);
                            }
                        }

                        setPetitions(combinedList)
                        // console.log("combined list", combinedList)
                    }, (error)  => {
                        setErrorFlag(true)
                        setErrorMessage(error.toString())
                    })
            }, (error)  => {
                setErrorFlag(true)
                setErrorMessage(error.toString())
            })
        // console.log("combined petitions",petitions)
    }

    const editPetition = () => {
        const params: {
            title?: string,
            description?: string,
            categoryId?: number
        } = {}
        if (newTitle) {
            params.title = newTitle
        }
        if (newDescription) {
            params.description = newDescription
        }
        if (newCategory) {
            params.categoryId = newCategory
        }
        axios.patch('http://localhost:4941/api/v1/petitions/' + petitionId, params, {headers: {"X-Authorization": user.token}})
            .then((response) => {
                // console.log(response)
                location.reload()
            }, (error) => {
                setErrorFlag(true)
                setErrorMessage(error.toString())
                console.log(error)
            })
    }

    const putSupportTier = () => {
        if (supportTierDescription == "" || supportTierTitle == "") {
            setSnackMessage("Please fill all the required fields.")
            setSnackOpen(true)
            return
        }
        axios.put('http://localhost:4941/api/v1/petitions/' + petitionId + '/supportTiers',
            {title: supportTierTitle, description: supportTierDescription, cost: supportTierCost}, {headers: {"X-Authorization": user.token}})
            .then((response) => {
                console.log(response)
                location.reload()
            }, (error) => {
                setErrorFlag(true)
                setErrorMessage(error.toString())
                console.log(error)
            })
    }



    //edit dialog
    const [openEditDialog, setOpenEditDialog] = React.useState(false)
    const handleEditDialogOpen = () => {
        //reset all the vars
        setNewTitle("")
        setNewDescription("")
        setNewCategory(0)
        setOpenEditDialog(true)
    }
    const handleEditDialogClose = () => {
        setOpenEditDialog(false)
    }



    //add support tier dialog
    const [openAddDialog, setOpenAddDialog] = React.useState(false)
    const handleAddDialogOpen = () => {
        //reset all the vars
        setOpenAddDialog(true)
    }
    const handleAddDialogClose = () => {
        setOpenAddDialog(false)
    }



    //edit button handler
    const handleEditClick = () => {
        if (user.userId == petition.ownerId) {
            handleEditDialogOpen()
        } else {
            setSnackMessage("Only the owner of a petition may edit it.")
            setSnackOpen(true)
        }
    }



    //add button handler
    const handleAddClick = () => {
        if (user.userId != petition.ownerId) {
            setSnackMessage("Only the owner of a petition may edit it.")
            setSnackOpen(true)
            return
        }
        if (supportTiers.length >= 3) {
            setSnackMessage("A petition can't have more than 3 support tiers.")
            setSnackOpen(true)
            return
        }
        handleAddDialogOpen()
    }



    //list mapping
    const tiers_list = () => supportTiers.map((supportTier: SupportTier) =>
        <SupportTierListObject key={supportTier.supportTierId} supportTier={supportTier} supporters={supporters} petition={petition}/>)

    const supporters_list = () => supporters.map((supporter: Supporter) =>
        <SupporterObject key={supporter.timestamp} supporter={supporter} supportTiers={petition.supportTiers}/>)

    const similar_petitions_list = () => petitions.map((petition: Petition) =>
        <PetitionListObject key={ petition.petitionId + petition.title } petition= {petition} categories={categories}/>)



    // state update methods
    const updateNewTitleState = (event: { target: { value: React.SetStateAction<string>; }; }) => {
        setNewTitle(event.target.value)
    }
    const updateNewDescriptionState = (event: { target: { value: React.SetStateAction<string>; }; }) => {
        setNewDescription(event.target.value)
    }
    const updateNewCategoryState = (event: React.ChangeEvent<{ value: number }>) => {
        setNewCategory(event.target.value)
    }
    const updateSupportTierTitleState = (event: { target: { value: React.SetStateAction<string>; }; }) => {
        setSupportTierTitle(event.target.value)
    }
    const updateSupportTierDescriptionState = (event: { target: { value: React.SetStateAction<string>; }; }) => {
        setSupportTierDescription(event.target.value)
    }
    const updateSupportTierCostState = (event) => {
        const newValue = parseInt(event.target.value, 10); // 10 is the radix/base

        // Check if newValue is a valid number
        if (!isNaN(newValue)) {
            setSupportTierCost(newValue);
        } else {
            console.error('Invalid input value. Please enter a valid number.');
        }
    }



    //snacks
    const [snackOpen, setSnackOpen] = React.useState(false)
    const [snackMessage, setSnackMessage] = React.useState("")
    const handleSnackClose = (event?: React.SyntheticEvent | Event, reason?: string) => {
        if (reason === 'clickaway') {
            return;
        }
        setSnackOpen(false);
    };



    //css styling
    const page: CSS.Properties = {
        padding: "10px",
        margin: "20px",
        width: "1200px"
    }



    return (
        <div>
            <AppBarObject/>
            <Paper elevation={3} style={page}>
                {errorFlag ?
                    <Alert severity="error">
                        <AlertTitle> Error </AlertTitle>
                        {errorMessage}
                    </Alert> : ""}
                <h1>{petition?.title}</h1>
                <PetitionDetailsObject petition={petition}/>
                <Container>
                    <Button variant={"outlined"} size={"large"} onClick={handleEditClick}>Edit Basic Info</Button>
                </Container>
                <h1>Support Tiers</h1>
                <div style={{flexWrap: "wrap", display: "inline-flex"}}>
                    {tiers_list()}
                </div>
                <Container>
                    <Button variant={"outlined"} size={"large"} onClick={handleAddClick}>Add a Support Tier</Button>
                </Container>
                <h1>Supporters</h1>
                <div>
                    {supporters_list()}
                </div>
            </Paper>
            <Paper elevation={3} style={{
                padding: "10px",
                margin: "20px",
                width: "1500px"
            }}>
                <h1>Similar Petitions</h1>
                <div style={{flexWrap: "wrap", display: "inline-flex"}}>
                    {errorFlag ?
                        <Alert severity="error">
                            <AlertTitle> Error </AlertTitle>
                            {errorMessage}
                        </Alert> : ""}
                    {petitions.length > 0 && similar_petitions_list()}
                </div>
            </Paper>
            <Dialog
                open={openEditDialog}
                onClose={handleEditDialogClose}
                aria-labelledby="alert-dialog-title"
                aria-describedby="alert-dialog-description">
                <DialogTitle id="alert-dialog-title">
                    Edit Petition
                </DialogTitle>
                <DialogContent>
                    <Container disableGutters>
                        <TextField required id={"outlined-required"} label={"Title"} value={newTitle}
                                   onChange={updateNewTitleState}/>
                        <TextField required id={"outlined-required"} label={"Description"} value={newDescription}
                                   onChange={updateNewDescriptionState}/>
                    </Container>
                    <TextField
                        required
                        select
                        id={"outlined-select-required"}
                        label={"Category"}
                        value={newCategory}
                        onChange={updateNewCategoryState}
                    >
                        {categories.map((category: Category) => (
                            <MenuItem key={category.name} value={category.categoryId}>
                                {category.name}
                            </MenuItem>
                        ))}
                    </TextField>
                </DialogContent>
                <DialogActions>
                    <Button onClick={handleEditDialogClose}>Cancel</Button>
                    <Button variant="outlined" color="info" onClick={() => {
                        editPetition()
                        handleEditDialogClose()
                    }} autoFocus>
                        Submit
                    </Button>
                </DialogActions>
            </Dialog>
            <Dialog
                open={openAddDialog}
                onClose={handleAddDialogClose}
                aria-labelledby="alert-dialog-title"
                aria-describedby="alert-dialog-description">
                <DialogTitle id="alert-dialog-title">
                    Add a Support Tier
                </DialogTitle>
                <DialogContent style={{minWidth: "1000px"}}>
                    <h4>Support Tier</h4>
                    <TextField required id={"outlined-required"} label={"Title"} type={"string"}
                               value={supportTierTitle} onChange={updateSupportTierTitleState}></TextField>
                    <TextField required id={"outlined-required"} label={"Description"} type={"string"}
                               value={supportTierDescription} onChange={updateSupportTierDescriptionState}></TextField>
                    <TextField required id={"outlined-required"} label={"Cost"} type={"number"} value={supportTierCost}
                               onChange={updateSupportTierCostState}></TextField>
                </DialogContent>
                <DialogActions>
                    <Button onClick={handleAddDialogClose}>Cancel</Button>
                    <Button variant="outlined" color="success" onClick={() => {
                        putSupportTier()
                        handleAddDialogClose()
                    }} autoFocus>
                        Add
                    </Button>
                </DialogActions>
            </Dialog>
            <Snackbar
                autoHideDuration={6000}
                open={snackOpen}
                onClose={handleSnackClose}
                key={snackMessage}
            >
                <Alert onClose={handleSnackClose} severity="error" sx={{width: '100%'}}>
                    {snackMessage}
                </Alert>
            </Snackbar>
        </div>
    )
}

export default PetitionDetails