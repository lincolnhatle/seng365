import AppBarObject from "../components/AppBarObject.tsx";
import {useUserStore} from "../store";
import React from "react";
import axios from "axios";
import PetitionListObject from "../components/PetitionListObject.tsx";
import {Alert, AlertTitle, Paper} from "@mui/material";
import CSS from "csstype";


const MyPetitions = () => {
    const user = useUserStore(state => state.user)
    //petition list
    const [petitions, setPetitions] = React.useState<Array<Petition>>([])
    const [categories, setCategories] = React.useState<Array<Category>>([])
    //error vars
    const [errorFlag, setErrorFlag] = React.useState(false)
    const [errorMessage, setErrorMessage] = React.useState("")


    React.useEffect(() => {
        getMyPetitions()
        getCategories()
    },[setPetitions])



    //axios methods
    const getMyPetitions = () => {
        axios.get('http://localhost:4941/api/v1/petitions?ownerId=' + user.userId)
            .then((response) => {
                axios.get('http://localhost:4941/api/v1/petitions?supporterId=' + user.userId)
                    .then((response1) => {
                        setPetitions(response.data.petitions.concat(response1.data.petitions))
                    }, (error) => {
                        setErrorFlag(true)
                        setErrorMessage(error.toString())
                    })
            }, (error) => {
                setErrorFlag(true)
                setErrorMessage(error.toString())
            })
    }

    const getCategories = () => {
        axios.get('http://localhost:4941/api/v1/petitions/categories')
            .then((response) => {
                setCategories(response.data)
            }, (error)  => {
                setErrorFlag(true)
                setErrorMessage(error.toString())
            })
    }





    //list mapping
    const my_petitions_list = () => petitions.map((petition: Petition) =>
        <PetitionListObject key={ petition.petitionId + petition.title } petition= {petition} categories={categories}/>)



    //css styling
    const card: CSS.Properties = {
        padding: "10px",
        margin: "20px",
        width: "1500px"
    }



    return (
        <div>
            <AppBarObject/>
            <h1>My Petitions</h1>
            <Paper elevation={3} style={card}>
                <div style={{flexWrap: "wrap", display: "inline-flex"}}>
                    {errorFlag ?
                        <Alert severity="error">
                            <AlertTitle> Error </AlertTitle>
                            {errorMessage}
                        </Alert> : ""}
                    {my_petitions_list()}
                </div>
            </Paper>
        </div>
    )
}

export default MyPetitions