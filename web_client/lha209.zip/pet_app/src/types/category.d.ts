type Category = {
    categoryId: number,
    name: string,
}