import CSS from "csstype";
import React from 'react';
import {
    Alert,
    AlertTitle,
    Avatar,
    Button,
    Card,
    CardActions,
    CardContent, Container, Dialog, DialogActions, DialogContent,
    DialogTitle, Snackbar, TextField,
    Typography
} from "@mui/material";
import {useUserStore} from "../store";
import axios from "axios";
import {BackpackTwoTone} from "@mui/icons-material";

const UserProfileObject = () => {
    //user vars
    const user = useUserStore(state => state.user)
    const [userFull, setUserFull] = React.useState({
        email: "",
        firstName: "",
        lastName: ""
    })
    //edited user vars
    const [edits, setEdits] = React.useState({})
    const [firstName, setFirstName] = React.useState("")
    const [lastName, setLastName] = React.useState("")
    const [email, setEmail] = React.useState("")
    const [currentPassword, setCurrentPassword] = React.useState("")
    const [password, setPassword] = React.useState("")
    //img vars
    const [img, setImg] = React.useState<File | null>(null)
    const fileInputRef = React.useRef<HTMLInputElement>(null)
    //jsx vars
    const [isHidden, setIsHidden] = React.useState(true)
    //error vars
    const [errorFlag, setErrorFlag] = React.useState(false)
    const [errorMessage, setErrorMessage] = React.useState("")



    React.useEffect(() => {
        getUserFull()
    }, [user.userId])



    //axios methods
    const getUserFull = () => {
        axios.get('http://localhost:4941/api/v1/users/' + user.userId, {headers:{"X-Authorization": user.token}})
            .then((response) => {
                setUserFull(response.data)
            }, (error)  => {
                setErrorFlag(true)
                setErrorMessage(error.toString())
            })
    }

    const editUserFull = () => {
        axios.patch('http://localhost:4941/api/v1/users/' + user.userId, edits, {headers: {"X-Authorization": user.token}})
            .then((response) => {
                console.log(response)
                location.reload()
            }, (error) => {
                setErrorFlag(true)
                setErrorMessage(error.toString())
                console.log(error)
            })
    }

    const deleteImage = () => {
        axios.delete('http://localhost:4941/api/v1/users/' + user.userId + '/image', {headers: {"X-Authorization": user.token}})
            .then((response) => {
                console.log(response)
                location.reload()
            }, (error) => {
                setErrorFlag(true)
                setErrorMessage(error.toString())
                console.log(error)
            })
    }

    const updateProfileImg = () => {
        if (user.token == "") {
            setSnackMessage("Must be logged in to edit your profile.")
            setSnackOpen(true)
            return
        }
        if (img == null) {
            setSnackMessage("No image was selected.")
            setSnackOpen(true)
            return
        }
        axios.put('http://localhost:4941/api/v1/users/' + user.userId + "/image", img, {headers:{"X-Authorization": user.token, "Content-type": img.type}})
            .then(() => {
                location.reload()
            }, (error)  => {
                setErrorFlag(true)
                setErrorMessage(error.toString())
                console.log(error)
            })
    }



    //edit dialog
    const [openEditDialog, setOpenEditDialog] = React.useState(false)
    const handleEditDialogOpen = () => {
        setOpenEditDialog(true)
    }
    const handleEditDialogClose = () => {
        setEdits({})
        setOpenEditDialog(false)
    }



    //picture dialog
    const [openImageDialog, setOpenImageDialog] = React.useState(false)
    const handleImageDialogOpen = () => {
        setOpenImageDialog(true)
    }
    const handleImageDialogClose = () => {
        setOpenImageDialog(false)
    }



    //img handling
    const handleImgChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        setImg(event.target.files[0])
    }
    const handleImgClick = () => {
        if (fileInputRef.current) {
            fileInputRef.current.click();
        }
    };



    //state update methods
    const updateFirstNameState = (event: { target: { value: React.SetStateAction<string>; }; }) => {
        setFirstName(event.target.value)
        setEdits(prevState => ({
            ...prevState,
            firstName: event.target.value
        }))
    }

    const updateLastNameState = (event: { target: { value: React.SetStateAction<string>; }; }) => {
        setLastName(event.target.value)
        setEdits(prevState => ({
            ...prevState,
            lastName: event.target.value
        }))
    }

    const updateEmailState = (event: { target: { value: React.SetStateAction<string>; }; }) => {
        setEmail(event.target.value)
        setEdits(prevState => ({
            ...prevState,
            email: event.target.value
        }))
    }

    const updatePasswordState = (event: { target: { value: React.SetStateAction<string>; }; }) => {
        setPassword(event.target.value)
        setEdits(prevState => ({
            ...prevState,
            password: event.target.value
        }))
    }

    const updateCurrentPasswordState = (event: { target: { value: React.SetStateAction<string>; }; }) => {
        setCurrentPassword(event.target.value)
        setEdits(prevState => ({
            ...prevState,
            currentPassword: event.target.value
        }))
    }



    //snacks
    const [snackOpen, setSnackOpen] = React.useState(false)
    const [snackMessage, setSnackMessage] = React.useState("")
    const handleSnackClose = (event?: React.SyntheticEvent | Event, reason?: string) => {
        if (reason === 'clickaway') {
            return;
        }
        setSnackOpen(false);
    };



    //css styles
    const card: CSS.Properties = {
        display: "block",
        height: "fit-content",
        width: "1200px",
        margin: "10px",
        padding: "0px"
    }



    return (
        <div>
            <Card sx={card}>
                <CardContent>
                    <h1>Profile</h1>
                    <Avatar
                        alt={userFull.firstName}
                        src={'http://localhost:4941/api/v1/users/' + user.userId + '/image'}
                        sx={{width: 400, height: 400}}
                        onClick={handleImageDialogOpen}
                    />
                    <Typography>
                        {"First Name: " + userFull.firstName}
                    </Typography>
                    <Typography>
                        {"LastName: " + userFull.lastName}
                    </Typography>
                    <Typography>
                        {"Email: " + userFull.email}
                    </Typography>
                </CardContent>
                {errorFlag ?
                    <Alert severity="error">
                        <AlertTitle> Error </AlertTitle>
                        {errorMessage}
                    </Alert> : ""}
                <CardActions>
                    <Button onClick={handleEditDialogOpen}>
                        Edit Profile
                    </Button>
                </CardActions>
            </Card>
            <Dialog
                open={openEditDialog}
                onClose={handleEditDialogClose}
                aria-labelledby="alert-dialog-title"
                aria-describedby="alert-dialog-description">
                <DialogTitle id="alert-dialog-title">
                    Edit User Profile
                </DialogTitle>
                <DialogContent>
                    <Container>
                        <TextField id="outlined-basic" type="text" label="New First" value={firstName} onChange={updateFirstNameState}/>
                    </Container>
                    <Container>
                        <TextField id="outlined-basic" label="New Last" value={lastName} onChange={updateLastNameState}/>
                    </Container>
                    <Container>
                        <TextField id="outlined-basic" label="New Email" value={email} onChange={updateEmailState}/>
                    </Container>
                    <Container>
                        <TextField id="outlined-basic" type={isHidden ? "password" : "text"} label="Current Password" value={currentPassword} onChange={updateCurrentPasswordState}/>
                        <TextField id="outlined-basic" type={isHidden ? "password" : "text"} label="New Password" value={password} onChange={updatePasswordState}/>
                        <Button onClick={() => setIsHidden(!isHidden)}>Show Password</Button>
                    </Container>
                </DialogContent>
                <DialogActions>
                <Button onClick={handleEditDialogClose}>Cancel</Button>
                    <Button variant="outlined" color="info" onClick={() => {
                        editUserFull()
                    }} autoFocus>
                        Submit
                    </Button>
                </DialogActions>
            </Dialog>
            <Dialog
                open={openImageDialog}
                onClose={handleImageDialogClose}
                aria-labelledby="alert-dialog-title"
                aria-describedby="alert-dialog-description">
                <DialogTitle id="alert-dialog-title">
                    Edit Profile Picture
                </DialogTitle>
                <DialogContent>
                    <Button onClick={handleImgClick}>
                        Change Profile Picture
                    </Button>
                    <input
                        type="file"
                        accept=".png, .jpg, .jpeg, .gif"
                        ref={fileInputRef}
                        style={{display: 'none'}}
                        onChange={handleImgChange}
                    />
                    <Typography>
                        {img?.name}
                    </Typography>
                </DialogContent>
                <DialogActions>
                    <Button variant="outlined" color="warning" onClick={() => {
                        deleteImage()
                    }}>
                        Remove Profile Picture
                    </Button>
                    <Button onClick={handleImageDialogClose}>Cancel</Button>
                    <Button variant="outlined" color="info" onClick={() => {
                        updateProfileImg()
                    }} autoFocus>
                        Submit
                    </Button>
                </DialogActions>
            </Dialog>
            <Snackbar
                autoHideDuration={6000}
                open={snackOpen}
                onClose={handleSnackClose}
                key={snackMessage}
            >
                <Alert onClose={handleSnackClose} severity="error" sx={{width: '100%'}}>
                    {snackMessage}
                </Alert>
            </Snackbar>
        </div>
    )
}

export default UserProfileObject