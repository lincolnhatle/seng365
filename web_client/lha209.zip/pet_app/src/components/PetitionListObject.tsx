import React from "react";
import {
    Alert,
    Avatar,
    Button,
    Card,
    CardActions,
    CardContent,
    CardMedia, Container, Dialog, DialogActions, DialogContent,
    DialogTitle, MenuItem,
    Snackbar, TextField,
    Typography
} from "@mui/material";
import {Link} from "react-router-dom";
import CSS from 'csstype';
import {useUserStore} from "../store";
import axios from "axios";

interface IPetitionListObjectProps {
    petition: Petition,
    categories: Category[]
}

const PetitionListObject = (props: IPetitionListObjectProps) => {
    //const variables/methods
    const [petition] = React.useState<Petition>(props.petition)
    const user = useUserStore(state => state.user)



    //axios methods
    const getCategoryName = (categoryId: number) => {
        for(let i=0; i < props.categories.length; i++) {
            if (props.categories[i].categoryId === categoryId)
                return props.categories[i].name
        }
    }

    const deletePetition = () => {
        axios.delete('http://localhost:4941/api/v1/petitions/' + petition.petitionId, {headers: {"X-Authorization": user.token}})
            .then(() => {
                location.reload()
            }, (error) => {
                console.log(error.response.status)
                setSnackMessage(error.toString())
                setSnackOpen(true)
            })
    }



    //delete dialog
    const [openDeleteDialog, setOpenDeleteDialog] = React.useState(false)
    const handleDeleteDialogOpen = () => {
        if (user.userId != petition.ownerId) {
            setSnackMessage("Only the owner of a petition can delete a petition. (Make sure you are logged in).")
            setSnackOpen(true)
            return
        }
        if (petition.numberOfSupporters > 0) {
            setSnackMessage("You can't delete a petition that already has support.")
            setSnackOpen(true)
            return
        }
        setOpenDeleteDialog(true)
    }

    const handleDeleteDialogClose = () => {
        setOpenDeleteDialog(false)
    }



    //snacks
    const [snackOpen, setSnackOpen] = React.useState(false)
    const [snackMessage, setSnackMessage] = React.useState("")
    const handleSnackClose = (event?: React.SyntheticEvent | Event, reason?: string) => {
        if (reason === 'clickaway') {
            return;
        }
        setSnackOpen(false);
    };



    //card
    const petitionCardStyles: CSS.Properties = {
        display: "inline-block",
        height: "fit-content",
        width: "450px",
        margin: "10px",
        padding: "0px"
    }



    return (
        <div>
            <Card sx={petitionCardStyles}>
                <CardMedia
                    component="img"
                    height="200"
                    width="200"
                    sx={{objectFit:"cover"}}
                    image={'http://localhost:4941/api/v1/petitions/' + props.petition.petitionId + '/image'}
                    alt="Auction hero"
                />
                <CardContent>
                    <Typography fontWeight="fontWeightMedium">
                        {petition.title} {'\n'}
                    </Typography>
                    <Typography variant="body2">
                        {petition.creationDate + '\n'} {', ' + getCategoryName(petition.categoryId) + ', \n'}
                        {petition.ownerFirstName + ' ' + petition.ownerLastName + ', \n'}
                        {"\n Cost $" + petition.supportingCost}
                    </Typography>
                    <Typography>
                        <Link to={'/petitions/' + props.petition.petitionId}>Details</Link>
                    </Typography>
                </CardContent>
                <Avatar
                    alt={props.petition.ownerFirstName}
                    src={'http://localhost:4941/api/v1/users/' + props.petition.ownerId + '/image'}
                    sx={{width: 69, height: 69}}
                />
                <CardActions>
                    <Button variant={"outlined"} color={"error"} onClick={handleDeleteDialogOpen}>
                        Delete
                    </Button>
                </CardActions>
            </Card>
            <Dialog
                open={openDeleteDialog}
                onClose={handleDeleteDialogClose}
                aria-labelledby="alert-dialog-title"
                aria-describedby="alert-dialog-description">
                <DialogTitle id="alert-dialog-title">
                    Delete a Petition
                </DialogTitle>
                <DialogContent>
                    <Typography>
                        Are you sure you'd like to delete this petition?
                    </Typography>
                </DialogContent>
                <DialogActions>
                    <Button onClick={handleDeleteDialogClose}>Cancel</Button>
                    <Button variant="outlined" color="error" onClick={() => {
                        deletePetition()
                    }} autoFocus>
                        Delete
                    </Button>
                </DialogActions>
            </Dialog>
            <Snackbar
                autoHideDuration={6000}
                open={snackOpen}
                onClose={handleSnackClose}
                key={snackMessage}
            >
                <Alert onClose={handleSnackClose} severity="error" sx={{width: '100%'}}>
                    {snackMessage}
                </Alert>
            </Snackbar>
        </div>
    )
}

export default PetitionListObject