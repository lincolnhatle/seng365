import CSS from "csstype";
import {Avatar, Card, CardContent, Typography} from "@mui/material";
import React from "react";
import axios from "axios";

interface ISupporterObjectProps {
    supporter: Supporter,
    supportTiers: SupportTier[]
}

const SupporterObject = (props: ISupporterObjectProps) => {
    const [supporter] = React.useState(props.supporter)
    const [supportTiers] = React.useState<Array<SupportTier>>(props.supportTiers)
    const [supportTierName, setSupportTierName] = React.useState("")

    React.useEffect(() => {
        getSupportTierName()
    }, [setSupportTierName])

    const getSupportTierName = () => {
        for(let i=0; i < supportTiers.length; i++) {
            if (supportTiers[i].supportTierId === supporter.supportTierId)
                setSupportTierName(supportTiers[i].title)
        }
    }

    const supporterCard: CSS.Properties = {
        display: "list-item",
        width: "fit-content",
        margin: "10px",
        padding: "0px"
    }

    return (
        <Card sx={supporterCard}>
            <CardContent>
                <Avatar
                    alt={supporter.supporterFirstName}
                    src={'http://localhost:4941/api/v1/users/' + supporter.supporterId + '/image'}
                    sx={{width: 69, height: 69}}
                />
                <Typography variant={"body2"}>
                    {supporter.supporterFirstName + " " + supporter.supporterLastName + ",      "}
                    {"Tier: " + supportTierName + ",     "}
                    {"Joined: " + supporter.timestamp}
                </Typography>
                <Typography variant={"overline"}>
                    {"Message of Support"}
                </Typography>
                <Typography variant={"body2"}>
                    {supporter.message}
                </Typography>
            </CardContent>
        </Card>
    )
}

export default SupporterObject