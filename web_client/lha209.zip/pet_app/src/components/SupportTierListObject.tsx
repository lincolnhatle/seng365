import CSS from "csstype";
import {
    Alert,
    AlertTitle, Button,
    Card,
    CardActionArea,
    CardActions,
    CardContent,
    Dialog, DialogActions, DialogContent, DialogContentText, DialogTitle,
    Snackbar, TextField,
    Typography
} from "@mui/material";
import {useUserStore} from "../store";
import React from "react";
import axios from "axios";


interface ISupportTierListObjectProps {
    supportTier: SupportTier,
    supporters: Supporter[],
    petition: PetitionFull
}

const SupportTierListObject = (props: ISupportTierListObjectProps) => {
    //user var
    const user = useUserStore(state => state.user)
    const [message, setMessage] = React.useState(" ")
    //edit support tier vars
    const [newTitle, setNewTitle] = React.useState("")
    const [newDescription, setNewDescription] = React.useState("")
    const [newCost, setNewCost] = React.useState(0)
    //error vars
    const [errorFlag, setErrorFlag] = React.useState(false)
    const [errorMessage, setErrorMessage] = React.useState("")



    //axios methods
    const supportPetition = () => {
        axios.post('http://localhost:4941/api/v1/petitions/' + props.petition.petitionId + '/supporters', {supportTierId: props.supportTier.supportTierId, message}, {headers:{"X-Authorization": user.token}})
            .then(() => {
                location.reload()
            }, (error) => {
                setErrorFlag(true)
                setErrorMessage(error.toString())
            })
    }

    const deleteSupportTier = () => {
        if (props.petition.supportTiers.length <= 1) {
            setSnackMessage("Petitions need at least 1 support tier.")
            setSnackOpen(true)
            return
        }
        axios.delete('http://localhost:4941/api/v1/petitions/' + props.petition.petitionId + '/supportTiers/' + props.supportTier.supportTierId, {headers: {"X-Authorization": user.token}})
            .then((response) => {
                console.log(response)
                location.reload()
            }, (error) => {
                setErrorFlag(true)
                setErrorMessage(error.toString())
            })
    }

    const editSupportTier = () => {
        const params: {
            title?: string,
            description?: string,
            cost?: number
        } = {}
        if (newTitle) {
            params.title = newTitle
        }
        if (newDescription) {
            params.description = newDescription
        }
        if (newCost || newCost == 0) {
            params.cost = newCost
        }
        console.log(newCost)
        axios.patch('http://localhost:4941/api/v1/petitions/' + props.petition.petitionId + '/supportTiers/' + props.supportTier.supportTierId, params, {headers: {"X-Authorization": user.token}})
        // axios.patch('http://localhost:4941/api/v1/petitions/' + props.petition.petitionId + '/supportTiers/' + props.supportTier.supportTierId,
        //     {title: newTitle, description: newDescription, cost: newCost}, {headers: {"X-Authorization": user.token}})
            .then((response) => {
                console.log(response)
                location.reload()
            }, (error) => {
                setErrorFlag(true)
                setErrorMessage(error.toString())
                console.log(error)
            })
    }



    //helpers
    const isAlreadySupporting = (supporters: Supporter[]) => {
        for (let i = 0; i < supporters.length; i++) {
            if (supporters[i].supporterId == user.userId && supporters[i].supportTierId == props.supportTier.supportTierId) {
                return true
            }
        }
        return false
    }
    const hasSupport = (supporters: Supporter[], tierId: number) => {
        for (let i = 0; i < supporters.length; i++) {
            if (supporters[i].supportTierId == tierId) {
                return true
            }
        }
        return false
    }



    //dialogs
    //support dialog
    const [openSupportDialog, setOpenSupportDialog] = React.useState(false)
    const handleSupportDialogOpen = () => {
        if (user.token == "") {
            setSnackMessage("Please log in to support a petition.")
            setSnackOpen(true)
            return
        }
        //check if owner is trying to support their own
        if (user.userId == props.petition.ownerId) {
            setSnackMessage("Nice try. You can't support a petition you own.")
            setSnackOpen(true)
            return
        }
        //check if already supporting this tier
        if (isAlreadySupporting(props.supporters)) {
            setSnackMessage("You already support this petition.")
            setSnackOpen(true)
            return
        }
        setOpenSupportDialog(true);
    }
    const handleSupportDialogClose = (textField: string) => {
        setMessage(textField)
        setOpenSupportDialog(false)
    }

    //delete dialog
    const [openDeleteDialog, setOpenDeleteDialog] = React.useState(false)
    const handleDeleteDialogOpen = () => {
        if (user.userId != props.petition.ownerId) {
            setSnackMessage("Only the owner of a petition can delete a petition. (Make sure you are logged in).")
            setSnackOpen(true)
            return
        }
        if (hasSupport(props.supporters, props.supportTier.supportTierId)) {
            setSnackMessage("You can't delete a petition that already has support.")
            setSnackOpen(true)
            return
        }
        setOpenDeleteDialog(true)
    }
    const handleDeleteDialogClose = () => {
        setOpenDeleteDialog(false)
    }

    //edit dialog
    const [openEditDialog, setOpenEditDialog] = React.useState(false)
    const handleEditDialogOpen = () => {
        if (hasSupport(props.supporters, props.supportTier.supportTierId)) {
            setSnackMessage("You can't edit a petition that already has support.")
            setSnackOpen(true)
            return
        }
        setOpenEditDialog(true)
    }
    const handleEditDialogClose = () => {
        setOpenEditDialog(false)
    }



    //snacks
    const [snackOpen, setSnackOpen] = React.useState(false)
    const [snackMessage, setSnackMessage] = React.useState("")
    const handleSnackClose = (event?: React.SyntheticEvent | Event, reason?: string) => {
        if (reason === 'clickaway') {
            return;
        }
        setSnackOpen(false);
    };



    //state update methods
    const updateMessageState = (event: { target: { value: React.SetStateAction<string>; }; }) => {
        setMessage(event.target.value)
    }
    const updateNewTitleState = (event: { target: { value: React.SetStateAction<string>; }; }) => {
        setNewTitle(event.target.value)
    }
    const updateNewDescriptionState = (event: { target: { value: React.SetStateAction<string>; }; }) => {
        setNewDescription(event.target.value)
    }
    const updateNewCostState = (event) => {
        const newValue = parseInt(event.target.value, 10); // 10 is the radix/base
        console.log(typeof(newValue))

        // Check if newValue is a valid number
        if (!isNaN(newValue)) {
            setNewCost(() => newValue);
        } else {
            console.error('Invalid input value. Please enter a valid number.');
        }
    }



    //css styles
    const supportTierCard: CSS.Properties = {
        display: "inline-block",
        width: "300px",
        margin: "10px",
        padding: "0px"
    }

    return (
        <div>
            <Card elevation={3} style={supportTierCard}>
                <CardActionArea onClick={handleSupportDialogOpen}>
                    <CardContent>
                        <Typography variant={"h4"}>
                            {props.supportTier.title + " Tier"}
                        </Typography>
                        <Typography variant={"body2"}>
                            {"Cost: $" + props.supportTier.cost}
                        </Typography>
                        <Typography variant={"body2"}>
                            {"Description: " + props.supportTier.description}
                        </Typography>
                    </CardContent>
                    {errorFlag ?
                        <Alert severity="error">
                            <AlertTitle> Error </AlertTitle>
                            {errorMessage}
                        </Alert> : ""}
                </CardActionArea>
                <CardActions>
                    <Button variant={"outlined"} color={"error"} onClick={handleDeleteDialogOpen}>Delete</Button>
                    <Button variant={"outlined"} color={"info"} onClick={handleEditDialogOpen}>Edit</Button>
                </CardActions>
            </Card>
            <Dialog
                open={openSupportDialog}
                onClose={handleSupportDialogClose}
                aria-labelledby="alert-dialog-title"
                aria-describedby="alert-dialog-description">
                <DialogTitle id="alert-dialog-title">
                    {"Support User"}
                </DialogTitle>
                <DialogContent>
                    <DialogContentText id="alert-dialog-description">
                        Give a message of support?
                    </DialogContentText>
                    <TextField id={"outlined-basic"} value={message} onChange={updateMessageState}/>
                </DialogContent>
                <DialogActions>
                    <Button onClick={handleSupportDialogClose}>Cancel</Button>
                    <Button variant="outlined" color="success" onClick={() => {
                        supportPetition()
                    }} autoFocus>
                        Give My Support
                    </Button>
                </DialogActions>
            </Dialog>
            <Dialog
                open={openDeleteDialog}
                onClose={handleDeleteDialogClose}
                aria-labelledby="alert-dialog-title"
                aria-describedby="alert-dialog-description">
                <DialogTitle id="alert-dialog-title">
                    Delete a Petition
                </DialogTitle>
                <DialogContent>
                    <Typography>
                        Are you sure you'd like to delete this petition?
                    </Typography>
                </DialogContent>
                <DialogActions>
                    <Button onClick={handleDeleteDialogClose}>Cancel</Button>
                    <Button variant="outlined" color="error" onClick={() => {
                        deleteSupportTier()
                        handleDeleteDialogClose()
                    }} autoFocus>
                        Delete
                    </Button>
                </DialogActions>
            </Dialog>
            <Dialog
                open={openEditDialog}
                onClose={handleEditDialogClose}
                aria-labelledby="alert-dialog-title"
                aria-describedby="alert-dialog-description">
                <DialogTitle id="alert-dialog-title">
                    Edit Support Tier
                </DialogTitle>
                <DialogContent>
                    <TextField required id={"outlined-required"} label={"Title"} type={"string"}
                               value={newTitle} onChange={updateNewTitleState}></TextField>
                    <TextField required id={"outlined-required"} label={"Description"} type={"string"}
                               value={newDescription} onChange={updateNewDescriptionState}></TextField>
                    <TextField required id={"outlined-required"} label={"Cost"} type={"number"} value={newCost}
                               onChange={updateNewCostState}></TextField>
                </DialogContent>
                <DialogActions>
                    <Button onClick={handleEditDialogClose}>Cancel</Button>
                    <Button variant="outlined" color="info" onClick={() => {
                        editSupportTier()
                        handleEditDialogClose()
                    }} autoFocus>
                        Submit
                    </Button>
                </DialogActions>
            </Dialog>
            <Snackbar
                autoHideDuration={6000}
                open={snackOpen}
                onClose={handleSnackClose}
                key={snackMessage}
            >
                <Alert onClose={handleSnackClose} severity="error" sx={{width: '100%'}}>
                    {snackMessage}
                </Alert>
            </Snackbar>
        </div>
    )
}

export default SupportTierListObject