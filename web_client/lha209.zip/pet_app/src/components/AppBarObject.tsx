import {
    AppBar,
    Container,
    Toolbar,
    Typography,
    Box,
    Tooltip,
    IconButton,
    Avatar,
    Menu, MenuItem, Button, ListItemIcon, Icon, Alert, AlertTitle, Snackbar
} from "@mui/material";
import React from "react";
import axios from "axios";

import {useUserStore} from "../store";
import {Link} from "react-router-dom";
import {Logout, Settings} from "@mui/icons-material";
import {useNavigate} from "react-router";

const AppBarObject = () => {
    const [anchorElUser, setAnchorElUser] = React.useState(null)
    const user = useUserStore(state => state.user)
    const removeUser = useUserStore(state => state.removeUser)
    const [errorFlag, setErrorFlag] = React.useState(false)
    const [errorMessage, setErrorMessage] = React.useState("")
    const navigate = useNavigate()
    const [userImg, setUserImg] = React.useState("")



    React.useEffect(() => {
        setUserImg('http://localhost:4941/api/v1/users/' + user.userId + '/image')
    }, [user])



    //axios methods
    const logoutUser = () => {
        if (user.token == "") {
            setSnackMessage("You are already logged out.")
            setSnackOpen(true)
            return
        }
        axios.post('http://localhost:4941/api/v1/users/logout',{}, {headers:{"X-Authorization": user.token}})
            .then(() => {
                removeUser()
                location.reload()
            }, (error)  => {
                setErrorMessage(error.toString())
                setErrorFlag(true)
            })
    }



    //handler methods
    const handleOpenUserMenu = (event) => {
        setAnchorElUser(event.currentTarget)
    }

    const handleCloseUserMenu = () => {
        setAnchorElUser(null)
    }

    const handleClickProfile = () => {
        if (user.token != "") {
            navigate('/user_profile')
        }
        handleCloseUserMenu()
    }



    //snacks
    const [snackOpen, setSnackOpen] = React.useState(false)
    const [snackMessage, setSnackMessage] = React.useState("")
    const handleSnackClose = (event?: React.SyntheticEvent | Event, reason?: string) => {
        if (reason === 'clickaway') {
            return;
        }
        setSnackOpen(false);
    };



    return (
        <AppBar position={"fixed"}>
            <Container maxWidth={"xl"}>
                <Toolbar disableGutters>
                    <Box sx={{ flexGrow: 0 }}>
                        <Tooltip title="Profile">
                            <IconButton onClick={handleOpenUserMenu} sx={{ p: 0 }}>
                                <Avatar
                                    src={userImg}
                                />
                            </IconButton>
                        </Tooltip>
                        <Menu
                            sx={{ mt: '45px' }}
                            id="menu-appbar"
                            anchorEl={anchorElUser}
                            anchorOrigin={{
                                vertical: 'top',
                                horizontal: 'right',
                            }}
                            keepMounted
                            transformOrigin={{
                                vertical: 'top',
                                horizontal: 'right',
                            }}
                            open={Boolean(anchorElUser)}
                            onClose={handleCloseUserMenu}
                        >
                            <MenuItem onClick={handleClickProfile}>
                                <ListItemIcon>
                                    <Icon fontSize="small" />
                                </ListItemIcon>
                               Profile
                            </MenuItem>
                            <MenuItem onClick={logoutUser}>
                                <ListItemIcon>
                                    <Logout fontSize="small" />
                                </ListItemIcon>
                                Logout
                            </MenuItem>
                        </Menu>
                    </Box>
                    <Button color={"inherit"} onClick={() => navigate('/sign_in')}>
                        Sign In
                    </Button>
                    <Button color={"inherit"} onClick={() => navigate('/')}>
                        Home
                    </Button>
                    <Button color={"inherit"} onClick={() => navigate('/my_petitions')}>
                        My Petitions
                    </Button>
                </Toolbar>
            </Container>
            {errorFlag ?
                <Alert severity="error">
                    <AlertTitle> Error </AlertTitle>
                    {errorMessage}
                </Alert> : ""}
            <Snackbar
                autoHideDuration={6000}
                open={snackOpen}
                onClose={handleSnackClose}
                key={snackMessage}
            >
                <Alert onClose={handleSnackClose} severity="error" sx={{width: '100%'}}>
                    {snackMessage}
                </Alert>
            </Snackbar>
        </AppBar>
    )
}

export default AppBarObject