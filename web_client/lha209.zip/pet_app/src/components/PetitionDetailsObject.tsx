import {Avatar, Card, CardContent, CardMedia, Typography} from "@mui/material";
import CSS from "csstype";

interface IPetitionDetailsObjectProps {
    petition: PetitionFull,
}

const PetitionDetailsObject = (props: IPetitionDetailsObjectProps) => {
    const petitionDetailsCardStyles: CSS.Properties = {
        display: "inline-block",
        width: "560px",
        margin: "10px",
        padding: "0px"
    }

    return (
        <Card sx={petitionDetailsCardStyles}>
            <CardMedia
                component="img"
                height="200"
                width="200"
                sx={{objectFit:"cover"}}
                image={'http://localhost:4941/api/v1/petitions/' + props.petition.petitionId + '/image'}
                alt="Auction hero"
            />
            <CardContent>
                <Typography align={"left"} fontWeight={"fontWeightHeavy"}>
                    {"Creation Date: " + props.petition.creationDate}
                </Typography>
                <Typography align={"left"} fontWeight={"fontWeightHeavy"}>
                    {"Number of Supporters: " + props.petition.numberOfSupporters}
                </Typography>
                <Typography align={"left"} fontWeight={"fontWeightHeavy"}>
                    {"Money Raised: $" + props.petition.moneyRaised}
                </Typography>
                <Typography align={"left"} fontWeight={"fontWeightHeavy"}>
                    {"Petition Owner: " + props.petition.ownerFirstName + " " + props.petition.ownerLastName}
                </Typography>
                <Avatar
                    alt="Owner"
                    src={'http://localhost:4941/api/v1/users/' + props.petition.ownerId + '/image'}
                    sx={{width: 69, height: 69}}
                />
                <Typography align={"left"} variant={"overline"}>
                    {"Description"}
                </Typography>
                <Typography align={"center"} fontWeight={"fontWeightHeavy"}>
                    {props.petition.description}
                </Typography>
            </CardContent>
        </Card>
    )
}

export default PetitionDetailsObject