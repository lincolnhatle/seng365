import './App.css'
import {BrowserRouter as Router, Routes, Route} from "react-router-dom";
import PetitionList from "./pages/PetitionList.tsx";
import PetitionDetails from "./pages/PetitionDetails.tsx";
import RegisterLogin from "./pages/RegisterLogin.tsx";
import UserProfile from "./pages/UserProfile.tsx";
import MyPetitions from "./pages/MyPetitions.tsx";

function App() {
  return (
    <>
      <div>
        <Router>
            <div>
                <Routes>
                    <Route path="/" element={<PetitionList/>}/>
                    <Route path="/petitions" element={<PetitionList/>}/>
                    <Route path="/petitions/:petitionId" element={<PetitionDetails/>}/>
                    <Route path="/sign_in" element={<RegisterLogin/>}/>
                    <Route path="/user_profile" element={<UserProfile/>}/>
                    <Route path="/my_petitions" element={<MyPetitions/>}/>
                </Routes>
            </div>
        </Router>
      </div>
    </>
  )
}

export default App
